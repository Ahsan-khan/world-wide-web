<?php

  session_start();

//checking if the session exists
//if the session is not set it redirects the user to the login form/page

  if(! isset($_SESSION["logged_in"])){
 //if(! isset($_SESSION["logged_in"]) && (isset($_POST['uname']) && isset($_POST['password']))){
      header("location:login.php");
  }

?>