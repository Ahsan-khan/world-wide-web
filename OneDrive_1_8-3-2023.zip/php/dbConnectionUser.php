<?php
$sname= "localhost";
$uname = "groenewj_cart";
$password = "cart599";
$db_name = "groenewj_cart";
$conn = mysqli_connect($sname, $uname, $password, $db_name);
if (!$conn) {
    echo "Connection failed!";
}