<?php
$_SESSION['current_page'] = $_SERVER['REQUEST_URI']; //added to return to prevous page
include 'protect.php'; //added this to make page only avaible to logged in users
//echo "This is" .(isset($_SESSION["logged_in"])); //degubbing 
//if(isset($_SESSION["logged_in"])){  //degubbing 
 // echo " True"; //degubbing 
//}  //degubbing 
//$_SESSION['current_page'] = $_SERVER['REQUEST_URI']; //added to return to prevous page
//session_start();
require_once("dbConnectionCart.php");
$db_handle = new DBController();
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
		if(!empty($_POST["quantity"])  and !empty($_SESSION["logged_in"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM tblproduct WHERE code='" . $_GET["code"] . "'");
			$itemArray = array($productByCode[0]["code"]=>array('name'=>$productByCode[0]["name"], 'code'=>$productByCode[0]["code"], 'quantity'=>$_POST["quantity"], 'price'=>$productByCode[0]["price"], 'image'=>$productByCode[0]["image"]));
			$pId = $_POST["productId"];
			$uId = $db_handle->runQuery("SELECT id FROM users WHERE user_name='" . $_SESSION["user_name"] . "'")[0]["id"];
			$successOrFailure = $db_handle->insertQuery("INSERT INTO productsincarts (userId, productId, quantity) VALUES (" . $uId . ", " . $pId . ", " . $_POST["quantity"] . ")");
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($productByCode[0]["code"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($productByCode[0]["code"] == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);		
						//and drop row from database
						$db_handle->otherQuery("DELETE FROM productsincarts WHERE userId='" . $_SESSION["id"] . "' AND productId='" . $_GET["id"] . "'" );					
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
		//and drop rows in database
		$db_handle->otherQuery("DELETE FROM productsincarts WHERE userId='" . $_SESSION["id"] . "'");
	break;	
}
}
?>

<html>
<head>
<meta http-equiv="refresh" content="1000">
<title>Shopping Cart</title>
<link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="../css/cart.css" rel="stylesheet">
<link href="../css/mobile.css" rel="stylesheet" media="screen and (max-width: 960px)"> 
</head>

<body>

<header><h1>Jacob's Performance </h1></header>
<div class="wrapper">


<h7> "We power your ride into the Fastlane!"
<?php if (isset($_SESSION["logged_in"])): 
    echo " Welcome, " . $_SESSION['user_name'] . " " ?><a href="../php/logout.php">Logout</a>
    <?php else:
    echo " Click here to Login, " ?> <a href="../php/login.php">Login</a>
<?php 
endif; 
?></h7>
<nav>
			<ul>
			<li><a href="index.php">Home</a></li>        
	    <li><a href="shop.php">Shop</a></li>
			<li><a href="legal.php">Legal</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li><a href="feedback.php">Feedback</a></li>
			<?php if (isset($_SESSION["logged_in"])): ?>
			  <li><a href="tips_and_tricks.php">Tips & Tricks</a></li>
        <li><a href=""><em>Cart</em></a></li>
      <?php 
      endif; 
      ?>		
			</ul>		
</nav>






<div id="shopping-cart">
<h3>Shopping Cart</h3>


<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total_price = 0;
?>	
<table class="tbl-cart" cellpadding="10" cellspacing="1">
<tbody>
<tr>
<th style="text-align:left;">Name</th>
<th style="text-align:left;" >Code</th>
<th style="text-align:right;"  width="5%">Qty</th>
<th style="text-align:right;" width="10%">Unit Price</th>
<th style="text-align:right;" width="10%">Price</th>
<th style="text-align:center;" width="5%">Remove</th>
</tr>
<a id="btnEmpty" href="shop.php?action=empty" onclick="return confirm('Are you sure, you want to empty the cart?');" >Empty Cart</a>
<?php		
    foreach ($_SESSION["cart_item"] as $item){
				
				
        $item_price = $item["quantity"]*$item["price"];
		?>
				
				<tr>
				<td><img src="<?php echo $item["image"]; ?>" class="cart-item-image" /><?php echo $item["name"]; ?></td>
				
				
				
				
                <td><?php echo $item["code"]; ?></td>
				<td style="text-align:right;"><?php echo $item["quantity"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ".$item["price"]; ?></td>
				<td  style="text-align:right;"><?php echo "$ ". number_format($item_price,2); ?></td>
				<td style="text-align:center;"><a href=<?php echo "checkout.php?action=remove&code=".$item['code']."&id=".$item['id']; ?> class="btnRemoveAction"><img src="../pictures/icondelete.png" alt="Remove Item" /></a></td>
				</tr>
				
				
				<?php
				$total_quantity += $item["quantity"];
				$total_price += ($item["price"]*$item["quantity"]);
		}
		?>


<tr>
<td colspan="2" align="right">Total:</td>
<td align="right"><?php echo $total_quantity; ?></td>
<td align="right" colspan="2"><strong><?php echo "$ ".number_format($total_price, 2); ?></strong></td>
<td></td>
</tr>
</tbody>
</table>		
  <?php
} else {
?>
<div class="no-records">Your Cart is Empty</div>
<?php 
}
?>
</div>


<?php
//$page = $_SERVER['PHP_SELF'];
//$sec = "10";
?>

<h3>Checkout payment and credit card details</h3>

<form id="cartForm" action="https://formsubmit.co/groenewj@uwindsor.ca" method="POST">

  <div>
    <label for="firstname">First name:</label><br> 
    <input type="name" name="first name" placeholder="John" >
  </input>
  </div>  
  <div>
    <label for="lastname">Last name:</label><br> 
    <input type="name" name="last name" placeholder="Smith" >
  </input>
  </div> 
  <div>
    <label for="street">Unit/house number and street name:</label><br> 
    <input type="adresss" name="street" placeholder="1234 SW ave" >
  </input>
  </div>  
  <div>
    <label for="city">City name:</label><br> 
    <input type="name" name="city" placeholder="Windsor" >
  </input>
  </div> 
  <div>
    <label for="prov_state">Province or State:</label><br> 
    <input type="name" name="prov_state" placeholder="ON" >
  </input>
  </div> 
  <div> 
 <label for="country">Country:</label><br>
 <select name="country" id="country">
 <option value="canada" >Canada</option>
 <option value="usa" >USA</option>
 </select><br>
 </div>
 <div>    
    <label for="postal_zip">Postal or Zip code:</label><br> 
    <input type="text" name="postal_zip" placeholder="A9A 9B9" >    
  </input>
  </div> 
  <div>    
    <label for="email">Email:</label><br> 
    <input type="email" name="email" placeholder="Your_email@host.ca" >    
  </input>
  </div> 
  <div>    
    <label for="number">Phone number:</label><br> 
    <input type="text" name="number" placeholder="1-555-555-5555" >    
  </input>
  </div> 


  <div> 
  <label id="cardtype">Select credit card type:</label><br> 
  <input type="radio" name="cardtype" value="mc" >Master Card
  <input type="radio" name="cardtype" value="visa" >Visa
 <input type="radio" name="cardtype" value="am" >American Express
</input>
 </div>
 <div>
 <br><br>
 <div>    
    <label for="card_number">Card number:</label><br> 
    <input type="text" name="card_number" placeholder="4500 0000 00000" >    
  </input>
  </div> 
 
  <div>    
    <label for="exp">Expiration date:</label><br> 
    <input type="text" name="exp" placeholder="mm/yyyy" >    
  </input>
  </div> 
  
  <div>    
    <label for="cvv">CVV number:</label><br> 
    <input type="text" name="cvv" placeholder="999" >    
  </input>
  </div> 
  
   <div>
    <label for="about_us">How did you hear about us?</label><br> 
    <input type="text" name="about_us" placeholder="discount code">
  </input>
  </div>
  <?php foreach($_SESSION["cart_item"] as $item){?>
		<input type="hidden" name=<?php echo '"' . 'product ' . $item['id'] . '"' ?> value=<?php echo '"code: ' . $item["code"] . ', name: ' . $item["name"] . ', quantity: ' . $item["quantity"] . ', price: $' . $item["price"]*$item["quantity"] . '.00 "';?>>
  <?php } ?>
  <div>   
  <button type="submit" id="submit" value="Submit form">Submit</button>
	</div>
  <div>


<input type="hidden" name="_next" value="http://localhost/finalproject/php/thanks.php?action=empty">
<input type="hidden" name="_subject" value="New web order from Jacobs Performance">
<input type="hidden" name="_captcha" value="false">
</div>
</form>  




<footer><h3>Jacob's Performance &nbsp;&nbsp;&nbsp;<a href="shop.php">Continue Shopping</a></h3>

</footer>	
    </body>
</html>