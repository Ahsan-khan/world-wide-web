<?php 
session_start();
$_SESSION['current_page'] = "index.php"; //added to return to prevous page
?>
<!DOCTYPE html> 
<html>
<head>
<title>Jacob's Performance</title>
<link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="../css/main.css" rel="stylesheet">
<link href="../css/mobile.css" rel="stylesheet" media="screen and (max-width: 960px)"> 
</head>

<body>
<header><h1>Jacob's Performance </h1></header>

<div class="wrapper">

<h7> "We power your ride into the Fastlane!"
<?php if (isset($_SESSION["logged_in"])): 
    echo " Welcome, " . $_SESSION['user_name'] . " " ?><a href="../php/logout.php">Logout</a>
    <?php else:
    echo " Click here to Login, " ?> <a href="../php/login.php">Login</a>
<?php 
endif; 
?></h7>
<nav>
			<ul>
			<li><a href=""><em>Home</em></a></li>        
	        <li><a href="shop.php">Shop</a></li>
			<li><a href="legal.php">Legal</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li><a href="feedback.php">Feedback</a></li>
			<?php if (isset($_SESSION["logged_in"])): ?>
			<li><a href="tips_and_tricks.php">Tips & Tricks</a></li>
            <li><a href="../php/checkout.php">Cart</a></li>
            <?php 
            endif; 
            ?>		
			</ul>		
</nav>

<section id="col1">
<img src="../pictures/engine.jpeg"  alt="2004 Colorado with V8 swap"> 
<h3>2004 Colorado with V8 swap</h3>
<p>
My name is Jamie Groeneweg, most of you may know me as (04colyZQ8), my username on various 
automotive forums. I have been offering custom wiring harnesses, vehicle programming, and 
performance advice since 2010. Jacob’s Performance is a website with some resources for all GM 
vehicles, although the focus will be on the following two platforms: 2004-2012 Chevy Colorado/GMC 
canyon (GMT355), and 2006-2010 Hummer H3 (N153). <em>Please email Jacob’s Performance to setup a user login to view Tips & Tricks and Checkout your Cart </em><a href="mailto:jake_edward@hotmail.com">Jacob's Performance</a></p>
</section>

<section id="col2">
<img src="../pictures/harness.jpeg" alt="Custom engine harnesses"> 
<h3>Custom engine harnesses</h3>
<p>
Jacob’s Performance offers several wiring harness options for 
installing and swapping in a V8 motor into these two platforms, along with various manual and 
automatic transmission options. In General the two categories are Gen III 24x(crank reductor) V8s, 
and Gen IV 58x(crank reductor) V8s. Automatic transmission choices are 4L60E, 4L80E, 4L70E, and *6L80E/6L90E.
Any manual transmission can be used, but popular choices include the stock MA5 5spd, and the T56 6spd. *Note only available with 58X motors. </p> 
</section>

<section id="col3">
<img src="../pictures/programming.jpeg" alt="Custom control module programming"> 
<h3>Custom control module programming</h3>
<p>Jacob’s Performance also offers custom body control module 
programming, and various stock GM module replacement using factory
 GM programming. Custom manual operating systems for 58x, using both discrete 
clutch switch style (04-07) and 0-5 volt style (08-12). Feel free to 
contact us about programing GM modules for other platforms. </p> 
</section>

<footer><h3>Jacob's Performance &nbsp;&nbsp;&nbsp;<a href="#">^ Back to top.</a></h3>
 
</footer>
</div>

</body>
</html>



