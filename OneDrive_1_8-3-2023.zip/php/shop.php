<?php
session_start(); 
//echo "test " . $_SERVER['REQUEST_URI'];
//$_SESSION['current_page'] = $_SERVER['REQUEST_URI']; //added to return to prevous page
$_SESSION['current_page'] = "checkout.php";
//$_POST[$_SERVER['REQUEST_URI']]; //tryig this 

require_once("dbConnectionCart.php");
$db_handle = new DBController();
if(!empty($_GET["action"])) {
switch($_GET["action"]) {
	case "add":
			if(!empty($_POST["quantity"]) and !empty($_SESSION["logged_in"])) {
			$productByCode = $db_handle->runQuery("SELECT * FROM tblproduct WHERE code='" . $_GET["code"] . "'");
			$itemArray = array($productByCode[0]["code"]=>array('id'=>$productByCode[0]['id'], 'name'=>$productByCode[0]["name"], 'code'=>$productByCode[0]["code"], 'quantity'=>$_POST["quantity"], 'price'=>$productByCode[0]["price"], 'image'=>$productByCode[0]["image"]));
			$pId = $_POST["productId"];
			$uId = $db_handle->runQuery("SELECT id FROM users WHERE user_name='" . $_SESSION["user_name"] . "'")[0]["id"];
			$successOrFailure = $db_handle->otherQuery("INSERT INTO productsincarts (userId, productId, quantity) VALUES (" . $uId . ", " . $pId . ", " . $_POST["quantity"] . ")");
			
			if(!empty($_SESSION["cart_item"])) {
				if(in_array($productByCode[0]["code"],array_keys($_SESSION["cart_item"]))) {
					foreach($_SESSION["cart_item"] as $k => $v) {
							if($productByCode[0]["code"] == $k) {
								if(empty($_SESSION["cart_item"][$k]["quantity"])) {
									$_SESSION["cart_item"][$k]["quantity"] = 0;
								}
								$_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
							}
					}
				} else {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
				}
			} else {
				$_SESSION["cart_item"] = $itemArray;
			}
		}
	break;
	case "remove":
		if(!empty($_SESSION["cart_item"])) {
			foreach($_SESSION["cart_item"] as $k => $v) {
					if($_GET["code"] == $k)
						unset($_SESSION["cart_item"][$k]);		
						//and drop row from database
						$db_handle->otherQuery("DELETE FROM productsincarts WHERE userId='" . $_SESSION["id"] . "' AND productId='" . $_GET["id"] . "'" );
					if(empty($_SESSION["cart_item"]))
						unset($_SESSION["cart_item"]);
			}
		}
	break;
	case "empty":
		unset($_SESSION["cart_item"]);
		//and drop rows in database
		$db_handle->otherQuery("DELETE FROM productsincarts WHERE userId='" . $_SESSION["id"] . "'");
	break;	
}
}
?>
<html>
<head>
<title>Shopping Cart</title>
<link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="../css/cart.css" rel="stylesheet">
<link href="../css/mobile.css" rel="stylesheet" media="screen and (max-width: 960px)"> 
</head>

<body>
<header><h1>Jacob's Performance </h1></header>

<div class="wrapper">
<h7> "We power your ride into the Fastlane!"
<?php if (isset($_SESSION["logged_in"])): 
    echo " Welcome, " . $_SESSION['user_name'] . " " ?><a href="../php/logout.php">Logout</a>
    <?php else:
    echo " Click here to Login, " ?> <a href="../php/login.php">Login</a>
<?php 
endif; 
?></h7>
<nav>
	<ul>
		<li><a href="index.php">Home</a></li>        
	    <li><a href="shop.php"><em>Shop</em></a></li>
		<li><a href="legal.php">Legal</a></li>
		<li><a href="contact.php">Contact Us</a></li>
		<li><a href="feedback.php">Feedback</a></li>
		<?php if (isset($_SESSION["logged_in"])): ?>
			<li><a href="tips_and_tricks.php">Tips & Tricks</a></li>
        	<li><a href="checkout.php">Cart</a></li>
        <?php 
        endif; 
        ?>		
	</ul>		
</nav>

<h3><a id="btncheckout" href="checkout.php">Cart checkout  *See Note.</a></h3>


<div id="product-grid">
	<h3>Products</h3>
	<p>*Note in order to checkout you must Login, if you do not have an account Conact Us to setup one. <a href="mailto:jake_edward@hotmail.com">Jacob's Performance</a></p>

	<?php
	$product_array = $db_handle->runQuery("SELECT * FROM tblproduct ORDER BY id ASC");
	if (!empty($product_array)) { 
		foreach($product_array as $key=>$value){
	?>
		<div class="product-item">
			
			<form method="post" action="shop.php?action=add&code=<?php echo $product_array[$key]["code"]; ?>">
			
			<?php 
			$productId = $db_handle->runQuery("SELECT id FROM tblproduct WHERE code='" . $product_array[$key]["code"] . "'")[0]["id"];
			?>
			<input type="hidden" name="productId" value="<?php echo $productId; ?>"/>
			<div class="product-image"><img src="<?php echo $product_array[$key]["image"]; ?>"></div>
			<div class="product-tile-footer">
			<div class="product-title"><?php echo $product_array[$key]["name"]; ?></div>
			<div class="product-price"><?php echo "$".$product_array[$key]["price"]; ?></div>
			<div class="cart-action"><input type="text" class="product-quantity" name="quantity" value="1" size="2" /><input  type="submit" value="Add to Cart" class="btnAddAction" onclick="alert('Item added to cart')"/></div>
			
				
		</div>
			</form>
		</div>
	<?php
		}
	}
	?>


<footer><h3>Jacob's Performance &nbsp;&nbsp;&nbsp;<a href="checkout.php">Cart checkout *See Above Note.</a>&nbsp;&nbsp;&nbsp;<a href="#">^ Back to top.</a></h3>

</footer>	
</div>
</body>
</html>