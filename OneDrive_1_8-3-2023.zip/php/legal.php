<?php 
session_start();
$_SESSION['current_page'] = $_SERVER['REQUEST_URI']; //added to return to prevous page
?>
<!DOCTYPE html> 

<html>
<head>
<title>Legal Emissions and Noise Pollution</title>
<link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="../css/main.css" rel="stylesheet">
<link href="../css/mobile.css" rel="stylesheet" media="screen and (max-width: 960px)"> 
</head>

<body>
<header><h1>Jacob's Performance </h1></header>

<div class="wrapper">

<h7> "We power your ride into the Fastlane!"
	<?php if (isset($_SESSION["logged_in"])): 
		echo " Welcome, " . $_SESSION['user_name'] . " " ?><a href="../php/logout.php">Logout</a>
		<?php else:
		echo " Click here to Login, " ?> <a href="../php/login.php">Login</a>
	<?php 
	endif; 
	?></h7>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>        
			<li><a href="shop.php">Shop</a></li>
			<li><a href=""><em>Legal</em></a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li><a href="feedback.php">Feedback</a></li>
			<?php if (isset($_SESSION["logged_in"])): ?>
				<li><a href="tips_and_tricks.php">Tips & Tricks</a></li>
				<li><a href="checkout.php">Cart</a></li>
		    <?php 
		    endif; 
		    ?>		
		</ul>		
	</nav>

<section id="col1">
<h3>Emission laws*</h3>
<ul>
<p><b>Unless your rig is being used strictly for track racing or offroad 4x4 use. Then we strongly recommend the following:</b></p>

<li>Retain the EVAP system, purge valve, non vented gas cap, and hoses to and from gas tank. Just use the V8 motor EVAP solenoid. </li><br>

<li>Use a catalytic convertor, not only does it stink to those behind you it's typically illegal* to remove the convertor! So, use one, on 
each bank, on a V8 that means one per side of the vehicle. There are plenty of high-flow options to choose from, various companies.</li><br>

<li>Choose a camshaft profile that isn't to aggressive at idle, lose lumpy camps sound great, but be realistic, costs gas mileage, causes 
stalling, and limits low end street torque and power. It also causes needles unburned gases to go out the exhaust at idle, which
is bad for the environment </li><br>

<li>A typical requirement* is the use a swapped engine from the same year vehicle, and same class i.e.. truck to truck, or newer model year engine.
Also, you typically can use a lower class i.e.. car motor that isn't more than 2 years old or is newer than the candidate vehicle. Or you maybe able
to use an older engine long block, if its computer VIN, and emissions components are from a later model engine. </li><br> 

<li>Run after catalytic convertor (also called rear O2s) oxygen sensors, they are an important emissions requirement*, and they will tell you
if the convertor is clogged, which is also bad for performance. </li><br>
<p><b>*Check with your local State or Provincial laws regarding emissions laws, and emissions testing, some components and parts require C.A.R.B 
(California Air Resource Board) certification. Jacob's Performance, harnesses and components do not carry a C.A.R.B certificate, and therefore are not 
legal in the State of California, unless used for track or off-road purposes only.  </b></p>
</ul>
</section>


<section id="col2">
<ul>
<h3>Excessive noise pollution**</h3>
<p><b>Unless you have a trail rig or track only rig, we recommend reading the following:</b></p>

<li>Not only is it annoying to hear a loud V8 with little to no mufflers, it is also typically illegal**, and you risk getting a fine from the local police
and likely a Vehicle inspection required ticket*.</li><br>

<li>Make sure you use a muffler for single "Y" pipe, or mufflers for dual exhaust or "H" pipe setup. Make sure it meats the local DB requirements**.</li><br> 

<li>Typically "glass packs", and anything under series 40 (flow-master) is way to loud* for the street, weather it is aloud or not! Please keep your fellow road
user and neighbor in mind. </li><br>

<li>Regarding "burnouts" and "spinning tires", yes, it's fun, but only do so on a private road, or track where it is permitted to do so, otherwise you can have your 
vehicle impounded* and or fined heavily by the local police! You also risk damage to the local roadways. I don't think an accidental squawk of the tires especially if 
it is raining out, will hurt anyone, but do not stand on the brakes, and do a massive noisy smokey burnout! On a public roadway. Keep in mind that the tires are
 costly especially the high performance ones that most V8 owners are going to want to purchase for there ride. </li><br>

<li>We strongly recommend the use of some kind of traction bar system, a good locking rear end (like Eaton's True Trac) and Ultra performance street tires***, to
avoid loosing traction for both safety and to prevent tire spin, see above.</li><br>

<p><b>**Note always check with local laws regarding noise, and street racing rules etc.<br> 
***Note before requesting Jacob's Performance or your local tuner to increase or remove the vehicle speed limiter check your tires maximum rated speed, as 
most factory tires are not rated for more than 140-160km/hr and winter tires are rated even less. </b></p>
</ul>
</section>

<section id="col3">
<ul>
<h3>Insurance, appraisals, and theft prevention****</h3>
<p><b>On or offroad vehicles should be insured even if it isn't required offroad. Please read the following tips:</b></p>

<li>Some insurance companies will flat out deny any claim and or not even cover you even if you were not at fault, if you 
have not notified them of modifications done to your vehicle****.</li><br>

<li>Even if your insurance company doesn't require it, you should get your custom ride appraised, and keep all your receipts
in case of theft fire, or damage, having a professional appraisal of your vehicle will help replace the costly performance goodies you
added.</li><br>

<li>Increasing the style and performance of any vehicle makes it more attractive to thieves, you should consider getting a GPS theft
tracking device, a club, or brake pedal lock.</li><br>

<li>Any truck or SUV from 2004 to 2007 only uses Gm's Pass lock antitheft system, it is easily defeated. The chipped key option GM RPO code BAE
from 2008-2012 is a much more robust system, and unlikely to be stolen this way. (More likely to be towed away). Some insurance companies**** even 
offer discounts for vehicles with chipped keys. See below</li><br>

<li>Luckily Jacob's Performance can outfit any 2004 to 2012 Colorado/Canyon/H3 with a factory chipped key setup. See out shopping cart for more 
details. </li><br>

<li>Many companies render your insurance Null and void**** if caught street racing, and even on the track, the policy is typically not valid, same goes for 4x4ing and 
offroad/logging roads. </li></b>

<p><b>****Always check with local State and Provincial laws, and your local Insurance companies. </b></p>
</ul>
</section>

<footer><h3>Jacob's Performance &nbsp;&nbsp;&nbsp;<a href="#">^ Back to top.</a></h3>

</footer>
</div>

</body>
</html>
