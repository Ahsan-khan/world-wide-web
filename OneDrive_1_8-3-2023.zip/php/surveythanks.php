<?php 
session_start();
$_SESSION['current_page'] = $_SERVER['REQUEST_URI']; //added to return to prevous page
?>
<!DOCTYPE html> 

<html>
<head>
<title>Thanks for the feedback</title>
<link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="../css/main.css" rel="stylesheet">
<link href="../css/mobile.css" rel="stylesheet" media="screen and (max-width: 960px)"> 
</head>

<body>
<header><h1>Jacob's Performance </h1></header>

<div class="wrapper">

<h7> "We power your ride into the Fastlane!"
	<?php if (isset($_SESSION["logged_in"])): 
		echo " Welcome, " . $_SESSION['user_name'] . " " ?><a href="../php/logout.php">Logout</a>
		<?php else:
		echo " Click here to Login, " ?> <a href="../php/login.php">Login</a>
	<?php 
	endif; 
	?></h7>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>        
			<li><a href="shop.php">Shop</a></li>
			<li><a href="legal.php">Legal</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li><a href="feedback.php">Feedback</a></li>
			<?php if (isset($_SESSION["logged_in"])): ?>
				<li><a href="tips_and_tricks.php">Tips & Tricks</a></li>
				<li><a href="checkout.php">Cart</a></li>
		    <?php 
		    endif; 
		    ?>		
		</ul>		
	</nav>
<br>
<br>
<h3>Thanks for your feedback! </h3>
<footer><h3>Jacob's Performance</h3>

</footer>
</div>

</body>
</html>
