<?php 
//session_start();
$_SESSION['current_page'] = $_SERVER['REQUEST_URI']; //added to return to prevous page
include 'protect.php'; //added this to make page only avaible to logged in users
?>
<!DOCTYPE html> 

<html>
<head>
<title>Tips and Tricks</title>
<link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="../css/main.css" rel="stylesheet">
<link href="../css/mobile.css" rel="stylesheet" media="screen and (max-width: 960px)"> 
</head>

<body>
<header><h1>Jacob's Performance </h1></header>

<div class="wrapper">
<h7> "We power your ride into the Fastlane!"
	<?php if (isset($_SESSION["logged_in"])): 
		echo " Welcome, " . $_SESSION['user_name'] . " " ?><a href="../php/logout.php">Logout</a>
		<?php else:
		echo " Click here to Login, " ?> <a href="../php/login.php">Login</a>
	<?php 
	endif; 
	?></h7>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>        
			<li><a href="shop.php">Shop</a></li>
			<li><a href="legal.php">Legal</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li><a href="feedback.php">Feedback</a></li>
			<?php if (isset($_SESSION["logged_in"])): ?>
				<li><a href=""><em>Tips & Tricks</em></a></li>
				<li><a href="checkout.php">Cart</a></li>
		    <?php 
		    endif; 
		    ?>		
		</ul>		
	</nav>
	

<section id="col1">
<h3>Gen IV engine pictured, Gen III similar</h3>
<img src="../pictures/58xengine.jpg"  alt="Gen IV 58x engine"> 

<h3>Gen IV 58x engine choices</h3>
<ul>
<p><b>The Gen IV is highly recommended for swap candidates from years 2008 and up:</b></p><br>

<li>Gen IV V8 58x are from late 07 and up GM vehicles. </li><br> 

<li>Anything other than a Gen 4 5.3L 2009* and up with stock truck cam, and no DOD, will require a dyno tune. </li><br>

<li>You can also use a VVT motor as long as it is a 5.3L without a dyno tune, but you will need a different PCM. </li><br>

<li>If you get anything other than a LH9 motor you will need headers or Colorado/Canyon/H3 LH8/LH9 cast exhaust manifolds, and if 
you have a 4x4 or sit low to the ground you will need a LH8/LH9 oil pan kit, with dipstick. </li><br>

<li>*Note engines prior to 2009 (2007-2008) have a different intake manifold, Map sensor, oil pressure sender, that will cause a bit of a tunning headache.
We can do a bit of a work around using a custom tune, but it is easier to use a 09 and up motor. </li>

<p><b>The Gen III is not recommended, but can be done for swap candidates from years 2004-2007:</b></p><br>

<li>Gen III V8 24x are from select 1998-2007 GM vehicles. </li><br> 

<li>Anything other than a Gen III 5.3L/6.0L 2005-2006 from a GTO/SSR/Trailblazer/Envoy/97x** with cam, will require a dyno tune. (**Note DOD will not function) </li><br> 

<li>You can also use any Gen III 24x V8, but you will need a 4 bolt 6wire style throttle body, from either a LS2 or truck 88mm.</li><br>

<li>You also need two block mounted LS2 knock sensors, custom cruise switch, expensive E40 PCM, custom starter relay, Trailblazer pedal***</li><br>

<li>***Note we can provide a custom OS that uses the stock Colorado/Canyon/H3 pedal, and ignition switch. Contact US for further details</li>
</ul>
</section>


<section id="col2">
<h3>General Parts list for V8 swap</h3>
<img src="../pictures/partstools.jpg"  alt="Header Gaskets and Tools"> 
<h3>Colorado/Canyon/H3 <br>2004 through 2012 <br>for either Gen IV or Gen III</h3>
<ul>
<li>09 Colorado/Canyon/H3 v8 upper and lower rad hoses. </li><br>

<li>90-degree 5/8" and 3/4" heater hoses about 20" long, have me verify these before you would buy them. </li><br>

<li>Current performance engine mounts. </li><br>

<li>Ls2, or Ls3 intake manifold, unless your truck is 08 and up, then can run the truck intake. </li><br>

<li>2005 trailblazer or SSR 4 bolt throttle body, or LS2 TB for 58x engines, depending on computer choice. </li><br>

<li>2 feet 11/32" vacuum hose for brake booster. </li><br> 

<li>07 Colorado battery module and connector, turns battery light**** out on 06 and older Colorado with v8 swap. </li><br>

<li>****Note not required for 58x swaps with manual transmission and CTSV OS. </li><br>

<li>2004 corvette fuel filter regulator, for 2004-2005 Colorado’s with return style fuel system. </li><br>

<li>Custom fuel lines, Russell Performance, makes adapters for gm rails. </li><br>

<li>2005-2006 trailblazer SSR or full-size truck mass air flow sensor, and plastic reducer. (24x) </li><br>

<li>Or LS7 MAF and 09 and up LH9/LH8 stock intake or Volant setup.  </li><br>

<li>New battery cables. </li><br>

<li>Custom steering lines, or possibly 09 Colorado/Canyon/H3 v8 lines, (check rack port size). </li><br>

<li>Custom a/c lines or 09 Colorado/Canyon/H3 v8 suction line, custom high side. </li><br>

<li>New bellhousing, input shaft, torque converter for v8 4L60E with I.S.S (Input Speed Sensor on 58x setup) </li><br>

<li>Or manual transmission use LS2 or LS7 clutch kit, stock clutch salve, adapter kit to MA5, or stock F-body bellhousing
for T56, GTO T56 bell-housing will work with GTO or mini starter. </li><br>

<li>Black magic extreme 180 e-fan without controller. (Use PCM to control fans) </li><br>

<li>09-12 Colorado/Canyon V8 Doug Thorley Headers or OBX headers. Custom header back exhaust. </li> 
</section>

<section id="col3">
<h3>Common Problems</h3>
<ul>
<p><b>Trouble shooting:</p></b>

<li>Battery light constantly on, engine running, you will be required to purchase a 07-12 Colorado/Canyon/H3, 
battery module, or generator module (Not required with CTSV OS). The module has been bypassed in the PCM, and harness, 
the alt. will charge with, or without it, and the battery light being on, it will still charge. You can plug in this module,
 into the provided plug near the battery, and your light will go out. Or you can remove the LED light from the cluster. 
Early 2004 clusters do not seem to have this problem. </li><br>

<li>Instrument cluster is dead, no response, check all grounds, clean and tight? Check factory body harness ground pack at the 
right inner fender near intake. Do you have an aftermarket radio? Do you have a Schoshe or other brand chime module, these cause
 interference, on the PCM, BCM, and cluster data bus, please remove and unplug them, see if that fixes the cluster, or no start? 
They also cause random, and incorrect PCM, TCM, or body codes to set. </li><br>

<li>No start but, cluster dims, and security (pass-lock) light says on. do a security relearn.
Is there any life in the system, I think my computers are fried?? Turnkey on intake off, watch with a mirror or recorder, and 
listen for the throttle blade to click shut then spring back to slightly open. Listen for the fuel pump to whirl up. These are the 
basic heartbeat of the system, if the throttle blade moves, and fuel pump whirls up, then your battery might be weak, or the trucks 
not in neutral or park?  Check codes, check grounds. </li><br>

<li>Check your fuses, with a test light or multimeter, key on engine off both sides of every fuse should be "Hot: (show 11-14 volts VDC),
 except for the DRLs fuse, will only show voltage when the headlamp switch is on. Check that all your fuses are in place the
 V8 may use a new fuse that was not an option for your truck, or over the years somebody may have stolen or removed them. Check your owner’s
 manual, or label on the bottom side of the fuse box cover, will list each fuse, relay, and proper location. </li><br> 

<li>My e-fan randomly cycles on and off, truck running, temp gauge is cold? This is because you probably do not have your a/c hooked up yet? 
The truck is confused and sees high a/c pressure and attempts to turn on the fan(s) to cool the condenser. If you have a/c DTCs, or trouble 
codes, fix them first, then see of the fan works normal. </li><br>

<li>I scanned my truck some codes don't make sense, I'm getting P0700 (transmission mill light request) And or Can or network trouble codes? 
But I do not have any transmission codes? This is because the TCM is missing, the fuse is bad (check the inline fuse marked TCM, supplied with 
the harness) OR You are using a blue tooth OBD plug, through a app on your Tablet, PC, or phone. These cheap blue tooth readers, rarely read 
the TCM codes, and often miss diagnose the PCM codes. You can try a plug in OBD 2 scanner for "can" based vehicles, see if it picks up transmission codes. </li><br>

<li>What do I tell my shop or scanner how to scan or read my truck? Any body, ABS, cluster, Radio, and OnStar codes need to be read as the year make and model of 
your truck see, your door jamb sticker. In some extreme cases for some model scanners, you may need to unplug the Can wires you added pin 14, and 6, from the 
OBD II port to retrieve body codes. To scan the engine or TCM, tell the shop your truck/SUV is a the year and model of the swapped in V8 PCM OS.</li> 
  
</ul>
</section>

<footer><h3>Jacob's Performance &nbsp;&nbsp;&nbsp;<a href="#">^ Back to top.</a></h3>

</footer>
</div>

</body>
</html>
