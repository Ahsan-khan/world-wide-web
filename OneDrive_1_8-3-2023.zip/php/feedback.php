<?php 
session_start();
$_SESSION['current_page'] = $_SERVER['REQUEST_URI']; //added to return to prevous page
?>
<!DOCTYPE html> 

<html>
<head>
<title>Feed Back Page</title>
<link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="../css/main.css" rel="stylesheet">
<link href="../css/mobile.css" rel="stylesheet" media="screen and (max-width: 960px)"> 

</head>

<body>
<header><h1>Jacob's Performance </h1></header>

<div class="wrapper">

<h7> "We power your ride into the Fastlane!"
	<?php if (isset($_SESSION["logged_in"])): 
		echo " Welcome, " . $_SESSION['user_name'] . " " ?><a href="../php/logout.php">Logout</a>
		<?php else:
		echo " Click here to Login, " ?> <a href="../php/login.php">Login</a>
	<?php 
	endif; 
	?></h7>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>        
			<li><a href="shop.php">Shop</a></li>
			<li><a href="legal.php">Legal</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li><a href=""><em>Feedback</em></a></li>
			<?php if (isset($_SESSION["logged_in"])): ?>
				<li><a href="tips_and_tricks.php">Tips & Tricks</a></li>
				<li><a href="checkout.php">Cart</a></li>
		    <?php 
		    endif; 
		    ?>		
		</ul>		
	</nav>
<h3>Jacob's Performance would love to hear from you! <br>Please fill out our feedback form</h3>
<form action="https://formsubmit.co/groenewj@uwindsor.ca" method="POST">
  <div>
    <label for="firstname">First name:</label><br> 
    <input type="name" name="first name" placeholder="John" required>
  </input>
  </div>  
  <div>
    <label for="lastname">Last name:</label><br> 
    <input type="name" name="last name" placeholder="Smith" required>
  </input>
  </div> 
  <div>    
    <label for="email">Email:</label><br> 
    <input type="email" name="email" placeholder="Your_email@host.com" required>    
  </input>
  </div> 

   <div>
    <label for="aboutus">How did you hear about us? </label><br> 
    <input type="text" name="How did you hear about us" required>
  </input>
  </div>  
  <div><br>
  Do you have either of these vehicles? <br><br> 
  <label id="trucklist">2004-2012 Colorado/Canyon</label><br> 
  <input type="radio" name="trucklist" value="yes">Yes
  <input type="radio" name="trucklist" value="no">No
 </div>
 <div>
<label id="suvlist">2006-2010 Hummer H3</label><br> 
  <input type="radio" name="suvlist" value="yes">Yes
  <input type="radio" name="suvlist" value="no">No
 </div><br>
 <div> 
 <label for="transmission">Do you prefer auto or manual transmissions? </label><br>
 <select name="transmission" id="transmission">
 <option value="auto">Auto</option>
 <option value="manual">Manual</option>
 </select><br>
 </div>
<div><br>
  
  <label id="proglist">Which are you more interested in? </label><br> 
  <input type="radio" name="proglist" value="yes">BCM Programming
  <input type="radio" name="proglist" value="no">V8 swaps
 </div><br>
<div>
 
  <button type="submit" name="The form has been successfully submitted." id="submit">Submit</button>
  </div>
<input type="hidden" name="_next" value="http://localhost/finalproject/php/surveythanks.php">
<input type="hidden" name="_subject" value="New submission from Jacobs Performance">
<input type="hidden" name="_captcha" value="false">
</form>
<div>
<footer><h3>Jacob's Performance &nbsp;&nbsp;&nbsp;<a href="#">^ Back to top.</a></h3>

</footer>
</div> 
</body>
</html>
