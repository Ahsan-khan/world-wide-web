<?php 
session_start();
$_SESSION['current_page'] = $_SERVER['REQUEST_URI']; //added to return to prevous page
?>
<!DOCTYPE html> 

<html>
<head>
<title>Contact Us</title>
<link href='https://fonts.googleapis.com/css?family=Norican' rel='stylesheet' type='text/css'>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link href="../css/main.css" rel="stylesheet">
<link href="../css/mobile.css" rel="stylesheet" media="screen and (max-width: 960px)"> 
</head>

<body>
<header><h1>Jacob's Performance </h1></header>

<div class="wrapper">

<h7> "We power your ride into the Fastlane!"
	<?php if (isset($_SESSION["logged_in"])): 
		echo " Welcome, " . $_SESSION['user_name'] . " " ?><a href="../php/logout.php">Logout</a>
		<?php else:
		echo " Click here to Login, " ?> <a href="../php/login.php">Login</a>
	<?php 
	endif; 
	?></h7>
	<nav>
		<ul>
			<li><a href="index.php">Home</a></li>        
			<li><a href="shop.php">Shop</a></li>
			<li><a href="legal.php">Legal</a></li>
			<li><a href=""><em>Contact Us</em></a></li>
			<li><a href="feedback.php">Feedback</a></li>
			<?php if (isset($_SESSION["logged_in"])): ?>
				<li><a href="tips_and_tricks.php">Tips & Tricks</a></li>
				<li><a href="checkout.php">Cart</a></li>
		    <?php 
		    endif; 
		    ?>		
		</ul>		
	</nav>
<h3>Click on the Map to go to google maps</h3>
<class>
<a href="https://goo.gl/maps/QUNiS5ZQmDuWQxeC8"><img style="map" src="../pictures/map.png" alt="Custom engine harnesses"></a></class>
<h3>Contact Jacob's Performance</h3>
<p>C/O Jacob (Jamie) Groeneweg<br>
   1373 Campbell Ave<br>
   Windsor, ON<br>
   Canada<br>
   N9B 2J8<br>
   <br>
   <br>
   Cell: 604-880-2035<br>
   <br>
   Email: <a href="mailto:jake_edward@hotmail.com">Jacob's Performance</a><br>
   

</p>

<footer><h3>Jacob's Performance</h3>

</footer>
</div>

</body>
</html>
